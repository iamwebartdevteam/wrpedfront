import React from "react";
import CategoryDetails from "./CategoryDetails";

const CataDetails = () => {
  return <div>{/* <CategoryDetails /> */}</div>;
};

export default CataDetails;
