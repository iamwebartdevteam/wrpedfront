import React from "react";

const CommonCata = () => {
  return <div>CommonCata</div>;
};

export default CommonCata;
